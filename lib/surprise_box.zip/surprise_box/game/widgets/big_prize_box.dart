import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';

import '../../../assets.dart';

class BigPrizeBox extends StatefulWidget {
  const BigPrizeBox({super.key});

  @override
  State<BigPrizeBox> createState() => _BigPrizeBoxState();
}

class _BigPrizeBoxState extends State<BigPrizeBox>
    with SingleTickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<double> animation;
  late Timer timer;

  final List<String> images = [
    AppAssets.wingPointIcon,
    AppAssets.wingSmall,
    AppAssets.coinGroup,
  ];
  int currentIndex = 0;
  int get nextIndex => (currentIndex + 1) % images.length;

  @override
  void initState() {
    super.initState();
    animationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );

    animation = Tween<double>(begin: 0, end: pi).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeInOut),
    );
    timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _triggerFlip();
    });
  }

  void _triggerFlip() {
    if (animationController.isDismissed) {
      animationController.forward().then((_) {
        setState(() {
          currentIndex = nextIndex; // Updates state reactively
        });
      });
      ;
    } else if (animationController.isCompleted) {
      animationController.reverse().then((_) {
        setState(() {
          currentIndex = nextIndex; // Updates state reactively
        });
      });
      ;
    }
  }

  @override
  void dispose() {
    timer.cancel();
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 180,
      height: 180,

      decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage(AppAssets.circleFrame)),
      ),
      child: Container(
        padding: EdgeInsets.all(40),
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage(AppAssets.light)),
        ),
        child: Transform.flip(
          flipY: true,
          child: AnimatedBuilder(
            animation: animation,
            builder: (context, child) {
              final angle = animation.value;
              final isFrontVisible = angle <= pi / 2;

              return Transform(
                transform: Matrix4.identity()
                  ..setEntry(3, 2, 0.0008)
                  ..rotateY(angle),

                alignment: Alignment.center,

                child: Transform(
                  transform: Matrix4.identity()..rotateX(pi),
                  alignment: Alignment.center,
                  child: isFrontVisible
                      ? Image.asset(images[currentIndex], fit: .contain)
                      : Transform(
                          alignment: Alignment.center,
                          transform: Matrix4.identity()..rotateY(pi),
                          child: Image.asset(
                            images[currentIndex],
                            fit: .contain,
                          ),
                        ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
